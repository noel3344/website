import React from 'react';
import { Link } from 'react-router-dom';

const products = [
  {
    name: 'AC Airbuds Pro',
    description:
      'Experience true wireless freedom and stunning sound clarity with advanced noise cancellation.',
    image: 'https://images.unsplash.com/photo-1515940175183-6798529cb860?fm=jpg&q=60&w=800',
  },
  {
    name: 'AC Vision Pad',
    description:
      'The sleekest tablet for work and play. Ultra-fast, ultra-portable, and ultra-brilliant visuals.',
    image: 'https://images.unsplash.com/photo-1468495244123-6c6c332eeece?fm=jpg&q=60&w=800',
  },
  {
    name: 'AC SmartHome Hub',
    description:
      'Control your environment with a single touch. The AC Hub brings together all your devices effortlessly.',
    image: 'https://images.unsplash.com/photo-1723186773193-621feea595c5?fm=jpg&q=60&w=800',
  },
  {
    name: 'AC NightCam',
    description: 'Security and peace of mind in a compact, smart package. Perfect vision, day and night.',
    image: 'https://images.unsplash.com/photo-1684326204435-c18ae098f0fe?fm=jpg&q=60&w=800',
  },
  {
    name: 'AC DeskPad Ultra',
    description: 'Unclutter and power your workspace with our wireless charging smart desk pad.',
    image: 'https://plus.unsplash.com/premium_photo-1661329839124-cf8d7e2e1702?fm=jpg&q=60&w=800',
  },
  {
    name: 'AC Lifestyle Kit',
    description: 'A curated set of accessories for life on the go. Style meets smart functionality.',
    image: 'https://plus.unsplash.com/premium_photo-1661304671477-37c77d0c6930?fm=jpg&q=60&w=800',
  },
  {
    name: 'AC Retro Gadget',
    description: 'A modern classic inspired by the golden age of design. Collector’s edition.',
    image: 'https://images.unsplash.com/photo-1742753103280-52d5efc0709b?fm=jpg&q=60&w=800',
  },
  {
    name: 'AC MaxSound Speaker',
    description: 'Fill every room with immersive, crystal-clear audio. Portable and powerful.',
    image: 'https://images.unsplash.com/photo-1504610926078-a1611febcad3?fm=jpg&q=60&w=800',
  },
  {
    name: 'AC Health Tab',
    description: 'Monitor your health vitals easily with a stunning medical-grade tablet.',
    image: 'https://plus.unsplash.com/premium_photo-1698421947098-d68176a8f5b2?fm=jpg&q=60&w=800',
  },
  {
    name: 'AC Fashion Headphones',
    description: 'Hear every detail in style with our designer audio series.',
    image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?fm=jpg&q=60&w=800',
  },
  {
    name: 'AC Studio Camera',
    description: 'Professionally capture life’s moments—complete manual, pro lens included.',
    image: 'https://images.unsplash.com/photo-1465101011104-301e1a43a028?fm=jpg&q=60&w=800',
  },
  {
    name: 'AC MultiPlug Pro',
    description: 'Smarten any socket with our multi-function smart plug accessory.',
    image: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?fm=jpg&q=60&w=800',
  },
  {
    name: 'AC Work Companion',
    description: 'Ultimate productivity combo: keyboard, mouse, and notebook for the modern professional.',
    image: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?fm=jpg&q=60&w=800',
  },
  {
    name: 'AC MiniDrone',
    description: 'Capture 4K aerials and explore limitless space with palm-sized drone innovation.',
    image: 'https://images.unsplash.com/photo-1470246973918-29a93221c455?fm=jpg&q=60&w=800',
  },
];

export default function Products() {
  return (
    <div className="min-h-screen flex flex-col">
      <nav className="w-full flex items-center justify-between px-8 py-5 border-b">
        <div className="font-bold text-xl">About AC</div>
        <ul className="flex gap-8 text-md font-medium">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/products">Products</Link></li>
          <li><Link to="/about">About</Link></li>
          <li><Link to="/support">Support</Link></li>
        </ul>
      </nav>
      <main className="flex-1 py-20 max-w-5xl mx-auto">
        <h1 className="text-4xl font-bold mb-8">Our Products</h1>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
          {products.map((product, idx) => (
            <div key={idx} className="rounded shadow-lg bg-white flex flex-col">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-40 object-cover"
              />
              <div className="p-6 flex-1 flex flex-col">
                <h2 className="text-xl font-medium mb-2">{product.name}</h2>
                <p className="flex-1 mb-4">{product.description}</p>
                <Link to="/products" className="mt-auto px-4 py-2 rounded bg-zinc-900 text-white font-semibold hover:bg-zinc-800 text-center">
                  Learn More
                </Link>
              </div>
            </div>
          ))}
        </div>
      </main>
      <footer className="py-8 px-8 bg-zinc-900 text-white text-center">
        &copy; {new Date().getFullYear()} About AC. All rights reserved.
      </footer>
    </div>
  );
}
