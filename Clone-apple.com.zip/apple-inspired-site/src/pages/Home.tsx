import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const products = [
  {
    name: 'AC Airbuds Pro',
    description: 'Experience true wireless freedom and stunning sound clarity with advanced noise cancellation.',
    image: 'https://images.unsplash.com/photo-1515940175183-6798529cb860?fm=jpg&q=60&w=800',
    link: '/products',
  },
  {
    name: 'AC Vision Pad',
    description: 'The sleekest tablet for work and play. Ultra-fast, ultra-portable, and ultra-brilliant visuals.',
    image: 'https://images.unsplash.com/photo-1468495244123-6c6c332eeece?fm=jpg&q=60&w=800',
    link: '/products',
  },
  {
    name: 'AC SmartHome Hub',
    description: 'Control your environment with a single touch. The AC Hub brings together all your devices effortlessly.',
    image: 'https://images.unsplash.com/photo-1723186773193-621feea595c5?fm=jpg&q=60&w=800',
    link: '/products',
  },
  {
    name: 'AC NightCam',
    description: 'Security and peace of mind in a compact, smart package. Perfect vision, day and night.',
    image: 'https://images.unsplash.com/photo-1684326204435-c18ae098f0fe?fm=jpg&q=60&w=800',
    link: '/products',
  },
  {
    name: 'AC DeskPad Ultra',
    description: 'Unclutter and power your workspace with our wireless charging smart desk pad.',
    image: 'https://plus.unsplash.com/premium_photo-1661329839124-cf8d7e2e1702?fm=jpg&q=60&w=800',
    link: '/products',
  },
  {
    name: 'AC Lifestyle Kit',
    description: 'A curated set of accessories for life on the go. Style meets smart functionality.',
    image: 'https://plus.unsplash.com/premium_photo-1661304671477-37c77d0c6930?fm=jpg&q=60&w=800',
    link: '/products',
  },
  {
    name: 'AC Retro Gadget',
    description: 'A modern classic inspired by the golden age of design. Collector’s edition.',
    image: 'https://images.unsplash.com/photo-1742753103280-52d5efc0709b?fm=jpg&q=60&w=800',
    link: '/products',
  },
];

export default function Home() {
  const [startIdx, setStartIdx] = useState(0);
  const [backwardTimeout, setBackwardTimeout] = useState(null);

  const visibleProducts = products.slice(startIdx, startIdx + 3);

  const handleForward = () => {
    if (startIdx < products.length - 3) {
      setStartIdx(startIdx + 1);
    }
  };

  const canGoBack = startIdx > 0;
  const canGoForward = startIdx < products.length - 3;

  const handleBackward = () => {
    if (canGoBack && backwardTimeout === null) {
      const timeout = window.setTimeout(() => {
        setStartIdx(idx => (idx > 0 ? idx - 1 : 0));
        setBackwardTimeout(null);
      }, 20000);
      setBackwardTimeout(timeout);
    }
  };

  React.useEffect(() => {
    return () => {
      if (backwardTimeout !== null) {
        window.clearTimeout(backwardTimeout);
      }
    };
  }, [backwardTimeout]);

  return (
    <div>
      {/* Navigation Bar */}
      <nav className="w-full flex items-center justify-between px-8 py-5 border-b">
        <div className="font-bold text-xl">About AC</div>
        <ul className="flex gap-8 text-md font-medium">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/products">Products</Link></li>
          <li><Link to="/about">About</Link></li>
          <li><Link to="/support">Support</Link></li>
        </ul>
      </nav>
      {/* Hero Section */}
      <section className="relative w-full h-[540px] bg-gradient-to-b from-zinc-900 to-zinc-800 flex flex-col items-center justify-center text-white">
        <h1 className="text-5xl font-semibold mb-4">Technology, Evolved.</h1>
        <p className="text-xl mb-6 max-w-xl text-center">About AC crafts seamless, intuitive products that fit perfectly into your modern life. Experience innovation reimagined.</p>
        <Link to="/products" className="px-8 py-3 bg-zinc-100 text-zinc-900 rounded-full font-semibold hover:bg-zinc-200 transition">Shop Products</Link>
      </section>
      {/* Product Highlights - Carousel */}
      <section className="py-20 bg-white text-zinc-900">
        <div className="max-w-5xl mx-auto flex items-center gap-3">
          {/* Left arrow */}
          <button
            onClick={handleBackward}
            disabled={!canGoBack || backwardTimeout !== null}
            title="Previous"
            className={`h-8 w-8 rounded-full flex items-center justify-center mr-2 transition border ${!canGoBack || backwardTimeout ? 'opacity-40 cursor-not-allowed' : 'hover:bg-zinc-100'}`}
            aria-label="Previous"
          >
            &#8592;
          </button>
          {/* Product cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 flex-1">
            {visibleProducts.map((product, idx) => (
              <div key={idx} className="rounded-lg shadow-lg overflow-hidden flex flex-col">
                <img src={product.image} alt={product.name} className="w-full h-52 object-cover" />
                <div className="p-6 flex-1 flex flex-col">
                  <h2 className="text-2xl font-medium mb-2">{product.name}</h2>
                  <p className="flex-1 mb-4">{product.description}</p>
                  <Link to={product.link} className="font-semibold text-zinc-700 hover:text-zinc-900 mt-auto">Learn More</Link>
                </div>
              </div>
            ))}
          </div>
          {/* Right arrow */}
          <button
            onClick={handleForward}
            disabled={!canGoForward}
            title="Next"
            className={`h-8 w-8 rounded-full flex items-center justify-center ml-2 transition border ${!canGoForward ? 'opacity-40 cursor-not-allowed' : 'hover:bg-zinc-100'}`}
            aria-label="Next"
          >
            &#8594;
          </button>
        </div>
        {backwardTimeout !== null && (
          <div className="text-zinc-400 text-center text-sm mt-2">Going back in 20 seconds…</div>
        )}
      </section>
      {/* Promo/Section */}
      <section className="py-16 bg-zinc-50">
        <div className="max-w-4xl mx-auto flex flex-col items-center">
          <h3 className="text-3xl font-semibold mb-3">Smart Living Starts with AC</h3>
          <p className="max-w-xl text-center mb-4">
            Step into the world of connected living. Our latest AC SmartHome Hub bridges all your devices—so you stay in control, no matter where you are.
          </p>
          <Link to="/products" className="px-7 py-2 rounded-full bg-zinc-900 text-white font-semibold hover:bg-zinc-700 transition">Explore Smart Home</Link>
        </div>
      </section>
      {/* Footer */}
      <footer className="py-8 px-8 bg-zinc-900 text-white text-center">
        &copy; {new Date().getFullYear()} About AC. All rights reserved.
      </footer>
    </div>
  );
}
